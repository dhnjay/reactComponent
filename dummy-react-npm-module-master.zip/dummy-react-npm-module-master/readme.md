Dummy react component
====

This will be a how to guide for your fellow developers

```
<DummyComponent />
```

etc
===

Thanks