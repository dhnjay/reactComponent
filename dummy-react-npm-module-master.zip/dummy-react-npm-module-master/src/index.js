import React, { Component } from 'react';

export default class DummyComponent extends Component {

    render () {

        return (
            <div>I am a dummy react npm module</div>
        )

    }

}